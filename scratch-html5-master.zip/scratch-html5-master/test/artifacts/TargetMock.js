'use strict';

var targetMock = function() {
  return {
    'showBubble' : function() {},
    'showAsk' : function() {},
    'askAnswer' : 22
  };

}
